<?php
/**
 *
 * Template Name: Frontpage
 *
 * Displays the Home page.
 *
 * @package awpbusinesspress
 */

get_header();

do_action( 'awp_awpbusinesspress_frontpage', false);

get_footer();